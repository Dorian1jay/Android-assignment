package com.example.jay.activitylab;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by jay on 12/10/17.
 */

public class ActivityTwo extends AppCompatActivity{

    private static final String TAG ="ActivityTwo";

    // counters

    int onCreateCounter;
    int onStartCounter;
    int onResumeCounter;
    int onRestartCounter;



    public void displayCounters()
    {
        TextView onCreate2 = (TextView)  findViewById(R.id.onCreate2);
        onCreate2.setText("onCreate() calls: " + onCreateCounter);

        TextView onStart2 = (TextView)  findViewById(R.id.onStart2);
        onStart2.setText("OnStart() calls: " + onStartCounter);

        TextView onRestart2 = (TextView)  findViewById(R.id.onRestart2);
        onRestart2.setText("OnRestart() calls: "  + onRestartCounter);

        TextView onResume2 = (TextView)  findViewById(R.id.onResume2);
        onResume2.setText("OnResume() calls: " + onResumeCounter);



    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitytwo);
       
        Log.i(TAG, "onCreate: ActivityTwo");


        if (savedInstanceState != null) {
            // Restore value of members from saved state
            onCreateCounter = savedInstanceState.getInt("OnCreate");
            onStartCounter = savedInstanceState.getInt("OnStart");
            onResumeCounter = savedInstanceState.getInt("OnResume");
            onRestartCounter = savedInstanceState.getInt("OnRestart");

        }
        else {
            // Probably initialize members with default values for a new instance
            onCreateCounter = 0;
            onStartCounter = 0;
            onResumeCounter = 0;
            onRestartCounter = 0;
        }



       ++onCreateCounter ;

        //TextView onCreate2 = (TextView)  findViewById(R.id.onCreate2);

        displayCounters();

        TextView onStart2 = (TextView)  findViewById(R.id.onStart2);
        //onStart2.setText("OnStart() calls: " + onStartCounter);

        TextView onRestart2 = (TextView)  findViewById(R.id.onRestart2);
        //onRestart2.setText("OnRestart() calls: "  + onRestartCounter);







        Button btnCloseActivity = (Button) findViewById(R.id.btnCloseActivity);
        btnCloseActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "onClick: ActivityTwo");
                
                finish();

                //Intent close = new Intent(ActivityTwo.this,ActivityOne.class);
                //startActivity(close);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        onStartCounter ++;
       // TextView onStart2 = (TextView)  findViewById(R.id.onStart2);
        //onStart2.setText("OnStart() calls: " + onStartCounter);

        displayCounters();
       
        Log.i(TAG, "onStart: ActivityTwo");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //Log.d(TAG, "onRestart: Activity2");

        onRestartCounter+=1;
        displayCounters();
    }

    @Override
    protected void onResume() {
        super.onResume();
        onResumeCounter +=1;
        displayCounters();
        Log.i(TAG, "onResume: ActivityTwo");
       
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "onPause: ActivityTwo");
        
    }
    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {

        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG, "onSaveInstanceState: ActivityTwo");


        //saving counter ints
        savedInstanceState.putInt("OnCreate",onCreateCounter);
        savedInstanceState.putInt("OnStart",onStartCounter);
        savedInstanceState.putInt("OnResume",onResumeCounter);
        savedInstanceState.putInt("OnRestart",onRestartCounter);
    }


    /*
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d(TAG, "onRestoreInstanceState: ");


        //retriving counter ints
        onCreateCounter = savedInstanceState.getInt("OnCreate");
        onStartCounter = savedInstanceState.getInt("OnStart");
        onResumeCounter = savedInstanceState.getInt("OnResume");
        onRestartCounter = savedInstanceState.getInt("OnRestart");
    }*/





    @Override
    protected void onStop() {
        super.onStop();

        Log.i(TAG, "onStop: ActivityTwo");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onDestroy: ActivityTwo");
    }
}
