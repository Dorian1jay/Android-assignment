package com.example.jay.activitylab;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.LoginFilter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static android.R.attr.button;

public class ActivityOne extends AppCompatActivity {

    // counters

    int onCreateCount ;
    int onStartCount ;
    int onResumeCount;
    int onRestartCount;




    private static final String TAG = "ActivityOne";


    /*
    when on restore was implemented oncreate and on start ints were being restored after they were incremented
    as its called after onstart . took a while to figure this out . someonelse may have experienced the same thing
     */
    /*@Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        Log.i(TAG, "onRestoreInstanceState: ");


        //retriving counter ints
        onCreateCount = savedInstanceState.getInt("OnCreate") ;
        onStartCount = savedInstanceState.getInt("OnStart");
        onResumeCount = savedInstanceState.getInt("OnResume");
        onRestartCount = savedInstanceState.getInt("OnRestart");
    }
    */


    public void displayCounters()
    {
        TextView onCreate1 = (TextView)  findViewById(R.id.onCreate1);
        onCreate1.setText("onCreate() calls: " + onCreateCount);

        TextView onStart1 = (TextView)  findViewById(R.id.onStart1);
        onStart1.setText("OnStart() calls: " + onStartCount);

        TextView onResume1  = (TextView)  findViewById(R.id.onResume1);
        onResume1.setText("OnResume calls:" + onResumeCount);

        TextView onRestart1 = (TextView)  findViewById(R.id.onRestart1);
        onRestart1.setText("OnRestart() calls: "  + onRestartCount);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);
        //onCreateCount ++;

        Log.i(TAG, "onCreate: ");



        if (savedInstanceState != null) {
            // Restore value of members from saved state
            onCreateCount = savedInstanceState.getInt("OnCreate");
            onStartCount = savedInstanceState.getInt("OnStart");
            onResumeCount = savedInstanceState.getInt("OnResume");
            onRestartCount = savedInstanceState.getInt("OnRestart");

        }
        else {
            // Probably initialize members with default values for a new instance
            onCreateCount = 0;
            onStartCount = 0;
            onResumeCount = 0;
            onRestartCount = 0;
        }





       displayCounters();

        onCreateCount += 1;


        TextView onCreate1 = (TextView)  findViewById(R.id.onCreate1);

        TextView onStart1 = (TextView)  findViewById(R.id.onStart1);

        TextView onResume1  = (TextView)  findViewById(R.id.onResume1);

        TextView onRestart1 = (TextView)  findViewById(R.id.onRestart1);






        Button btnActivityTwo = (Button) findViewById(R.id.btnActivityTwo);
        btnActivityTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.i(TAG, "onClick: btnActivityTwo");

                Intent StartactivityTwo = new Intent(ActivityOne.this,ActivityTwo.class);
                startActivity(StartactivityTwo);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        onStartCount +=1;
        displayCounters();
        Log.i(TAG, "onStart: ");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        onRestartCount+=1;
        displayCounters();
        Log.i(TAG, "onRestart: ");
    }


    @Override
    protected void onResume() {
        super.onResume();
        onResumeCount +=1;
        displayCounters();
        Log.i(TAG, "onResume: ");
    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.i(TAG, "onPause: ");
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {

        super.onSaveInstanceState(savedInstanceState);

        Log.i(TAG, "onSaveInstanceState: ");

        //saving counter ints
        savedInstanceState.putInt("OnCreate",onCreateCount);
        savedInstanceState.putInt("OnStart",onStartCount);
        savedInstanceState.putInt("OnResume",onResumeCount);
        savedInstanceState.putInt("OnRestart",onRestartCount);
    }

    @Override
    protected void onStop() {
        super.onStop();

        Log.i(TAG, "onStop: ");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.i(TAG, "onDestroy: ");
        Log.i(TAG, "onCreate is : "+this.onCreateCount);


    }
}
